import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(const DestinyApp());
}

class DestinyApp extends StatelessWidget {
  const DestinyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Destiny App',
      home: const DestinyPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class DestinyPage extends StatefulWidget {
  const DestinyPage({super.key});

  @override
  State<DestinyPage> createState() => _DestinyPageState();
}

class _DestinyPageState extends State<DestinyPage> {
  int destinyNumber = 1;

  void changeDestiny() {
    setState(() {
      destinyNumber = Random().nextInt(5) + 1; 
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue,
      appBar: AppBar(
        title: const Text('Choose Your Destiny'),
        backgroundColor: Colors.blueAccent,
      ),
      body: Center(
        child: TextButton(
          onPressed: changeDestiny,
          child: Image.asset('assets/destiny$destinyNumber.jpg'),
        ),
      ),
    );
  }
}

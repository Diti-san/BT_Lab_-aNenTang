package com.example.bai8_destiny;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

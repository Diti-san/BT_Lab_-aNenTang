

final List<Map<String, Object>> questions = [
  {
    'question': 'Thủ đô của Việt Nam là?',
    'answers': ['Hà Nội', 'Hồ Chí Minh', 'Đà Nẵng'],
    'correct': 'Hà Nội',
  },
  {
    'question': '2 + 2 = ?',
    'answers': ['3', '4', '5'],
    'correct': '4',
  },
  {
    'question': 'Màu của bầu trời là gì?',
    'answers': ['Xanh', 'Đỏ', 'Vàng'],
    'correct': 'Xanh',
  },
  {
    'question': 'Động vật nào được gọi là "chúa sơn lâm"?',
    'answers': ['Sư tử', 'Hổ', 'Báo'],
    'correct': 'Hổ',
  },
  {
    'question': 'Ai là người sáng lập Microsoft?',
    'answers': ['Steve Jobs', 'Elon Musk', 'Bill Gates'],
    'correct': 'Bill Gates',
  },
  {
    'question': 'Sông nào dài nhất thế giới?',
    'answers': ['Amazon', 'Nile', 'Mississippi'],
    'correct': 'Nile',
  },
  {
    'question': 'Quốc gia nào có diện tích lớn nhất thế giới?',
    'answers': ['Nga', 'Mỹ', 'Canada'],
    'correct': 'Nga',
  },
  {
    'question': 'Môn thể thao vua là?',
    'answers': ['Bóng đá', 'Bóng rổ', 'Quần vợt'],
    'correct': 'Bóng đá',
  },
  {
    'question': 'Trong bảng tuần hoàn hóa học, ký hiệu của nước là gì?',
    'answers': ['O2', 'H2O', 'CO2'],
    'correct': 'H2O',
  },
  {
    'question': 'Loài chim nào có thể bay lùi?',
    'answers': ['Chim bồ câu', 'Chim sẻ', 'Chim ruồi'],
    'correct': 'Chim ruồi',
  },
];

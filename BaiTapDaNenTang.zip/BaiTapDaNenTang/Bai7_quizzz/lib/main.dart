import 'package:flutter/material.dart';
import 'ques.dart'; 

void main() {
  runApp(const QuizApp());
}

class QuizApp extends StatefulWidget {
  const QuizApp({super.key});

  @override
  State<QuizApp> createState() => _QuizAppState();
}

class _QuizAppState extends State<QuizApp> {
  int _currentQuestionIndex = 0;
  int _score = 0;

  void _answerQuestion(String answer) {
    if (answer == questions[_currentQuestionIndex]['correct']) {
      _score++;
    }
    setState(() {
      _currentQuestionIndex++;
    });
  }

  void _restartQuiz() {
    setState(() {
      _currentQuestionIndex = 0;
      _score = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool quizEnded = _currentQuestionIndex >= questions.length;

    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Quiz App'),
          backgroundColor: Colors.blueAccent,
        ),
        body: quizEnded
            ? Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Bạn đã đúng $_score/${questions.length} câu!',
                  style: const TextStyle(fontSize: 24)),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _restartQuiz,
                child: const Text('Chơi lại'),
              )
            ],
          ),
        )
            : Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              questions[_currentQuestionIndex]['question'] as String,
              style: const TextStyle(fontSize: 22),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ...(questions[_currentQuestionIndex]['answers'] as List<String>)
                .map((answer) => Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(
                  vertical: 5, horizontal: 30),
              child: ElevatedButton(
                onPressed: () => _answerQuestion(answer),
                child: Text(answer),
              ),
            )),
          ],
        ),
      ),
    );
  }
}

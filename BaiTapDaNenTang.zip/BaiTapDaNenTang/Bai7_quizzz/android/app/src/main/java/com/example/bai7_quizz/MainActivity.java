package com.example.bai7_quizz;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

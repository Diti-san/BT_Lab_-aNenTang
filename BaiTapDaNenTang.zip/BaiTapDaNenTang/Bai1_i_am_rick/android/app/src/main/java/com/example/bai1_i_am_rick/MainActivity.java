package com.example.bai1_i_am_rick;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

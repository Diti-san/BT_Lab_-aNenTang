package com.example.bai3_micard;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

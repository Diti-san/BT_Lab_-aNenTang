package com.example.bai4_magicball;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

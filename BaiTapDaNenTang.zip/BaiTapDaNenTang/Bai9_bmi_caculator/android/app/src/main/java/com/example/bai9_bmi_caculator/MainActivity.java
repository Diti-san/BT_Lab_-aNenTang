package com.example.bai9_bmi_caculator;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

import 'package:flutter/material.dart';

void main() {
  runApp(const BMICalculatorApp());
}

class BMICalculatorApp extends StatelessWidget {
  const BMICalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BMI Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0A0E21),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0A0E21),
        ),
      ),
      home: const InputPage(),
    );
  }
}

class InputPage extends StatefulWidget {
  const InputPage({super.key});

  @override
  State<InputPage> createState() => _InputPageState();
}

class _InputPageState extends State<InputPage> {
  final TextEditingController _heightController = TextEditingController(text: '170');
  final TextEditingController _weightController = TextEditingController(text: '60');

  double calculateBMI(double height, double weight) {
    double heightInMeter = height / 100;
    return weight / (heightInMeter * heightInMeter);
  }

  String getBMICategory(double bmi) {
    if (bmi < 18.5) {
      return "Gầy";
    } else if (bmi >= 18.5 && bmi < 24.9) {
      return "Bình thường";
    } else if (bmi >= 25 && bmi < 29.9) {
      return "Thừa cân";
    } else {
      return "Béo phì";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BMI Calculator'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Nhập Chiều Cao (cm)',
              style: TextStyle(fontSize: 20.0, color: Colors.grey),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _heightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                filled: true,
                fillColor: const Color(0xFF1D1E33),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                hintText: 'Nhập chiều cao',
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Nhập Cân Nặng (kg)',
              style: TextStyle(fontSize: 20.0, color: Colors.grey),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _weightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                filled: true,
                fillColor: const Color(0xFF1D1E33),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                hintText: 'Nhập cân nặng',
              ),
            ),
            const SizedBox(height: 30),
            GestureDetector(
              onTap: () {
                double? height = double.tryParse(_heightController.text);
                double? weight = double.tryParse(_weightController.text);

                if (height == null || weight == null || height <= 0 || weight <= 0) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Vui lòng nhập giá trị hợp lệ')),
                  );
                  return;
                }

                double bmi = calculateBMI(height, weight);
                String category = getBMICategory(bmi);

                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    backgroundColor: const Color(0xFF1D1E33),
                    title: const Text('Kết Quả BMI', style: TextStyle(color: Colors.white)),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          bmi.toStringAsFixed(1),
                          style: const TextStyle(fontSize: 50.0, color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 20),
                        Text(
                          category,
                          style: TextStyle(
                            fontSize: 25.0,
                            color: category == "Bình thường"
                                ? Colors.green
                                : (category == "Gầy" ? Colors.yellow : Colors.red),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Đóng', style: TextStyle(color: Colors.blue)),
                      ),
                    ],
                  ),
                );
              },
              child: Container(
                color: Colors.pink,
                height: 70.0,
                child: const Center(
                  child: Text(
                    'TÍNH BMI',
                    style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
